<?php
	header("location:login.html");
?>